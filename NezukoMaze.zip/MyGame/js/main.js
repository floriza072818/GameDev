var game = new Phaser.Game(window.innerWidth, window.innerHeight, Phaser.AUTO, '');

game.state.add('Boot', Nezuko.Boot);
game.state.add('Preloader', Nezuko.Preload);
game.state.add('MainMenu', Nezuko.MainMenu);
game.state.add('Game', Nezuko.Game);


game.state.start('Boot');
